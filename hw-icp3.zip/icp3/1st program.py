#Author: Rushika Karnati

class Employee:
    count = 0
    salary_cnt = 0
    def __init__(self, name, family, salary, department):
        self.name = name
        self.family = family
        self.salary = salary
        self.department = department
        Employee.count += 1
        Employee.salary_cnt = Employee.salary_cnt + salary

    def average_salary(self):
        return Employee.salary_cnt/Employee.count

class FulltimeEmployee(Employee):
    pass

fulltime_employee1 = FulltimeEmployee("Rushika", "Karnati", 35000, "administration")
fulltime_employee2 = FulltimeEmployee("santhosh", "Narendruni", 27000, "HR")
print("Fulltime Employees average salary using member function: {}".format(
    fulltime_employee2.average_salary()))
employee1 = Employee("prathusha", "kallem", 9000, "IT")
employee2 = Employee("Nandhan", "Valluri", 15000, "IT")
print("Employees average salary using member function: {}".format(
    employee1.average_salary()))